#include<sstream>

#include "bus_manager.h"


//
//double CalculateTwoStopsDistance2(const StopPtr& p1, const StopPtr& p2)
//{
//
//    double tmp = sin((p2->longitude - p1->longitude)/2);
//    cout << "tmp: " << tmp <<endl;
//    const double under_root_right = cos(p1->latitude) * cos(p2->latitude) * (tmp * tmp);
//
//    tmp = sin((p2->latitude - p1->latitude)/2);
//    const double under_root = tmp * tmp + under_root_right;
//
//    const double d = 2 * kEarthR * asin(sqrt(under_root));
//
//    return d;
//}
//


//std::stringstream test_stream{
//        "4\n"
//        "Stop Tolstopaltsevo: 55.611087, 37.20829\n"
//        "Stop Marushkino: 55.595884, 37.209755   \n"
//        "Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka\n"
//        "Stop Rasskazovka: 55.632761, 37.333324  \n"
//        "1\n"
//        "Bus 750"
//};

//
//std::stringstream test_stream{
//        "10\n"
//        "Stop Tolstopaltsevo: 55.611087, 37.20829\n"
//        "Stop Marushkino: 55.595884, 37.209755\n"
//        "Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye \n"
//        "Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka\n"
//        "Stop Rasskazovka: 55.632761, 37.333324\n"
//        "Stop Biryulyovo Zapadnoye: 55.574371, 37.6517\n"
//        "Stop Biryusinka: 55.581065, 37.64839\n"
//        "Stop Universam: 55.587655, 37.645687\n"
//        "Stop Biryulyovo Tovarnaya: 55.592028, 37.653656\n"
//        "Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164\n"
//        "3\n"
//        "Bus 256\n"
//        "Bus 750\n"
//        "Bus 751"
//};

int main() {
//    auto p1 = make_shared<Stop>();
//    p1->latitude = 55.611087 * kPi / 180;
//    p1->longitude = 37.20829 * kPi / 180;
//
//    auto p2 = make_shared<Stop>();
//    p2->latitude = 55.595884 * kPi / 180;
//    p2->longitude = 37.209755 * kPi / 180;
//
//    auto p3 = make_shared<Stop>();
//    p3->latitude = 55.632761 * kPi / 180;
//    p3->longitude = 37.333324 * kPi / 180;
//
//    auto d1 = CalculateTwoStopsDistance2(p1, p2);
//    auto d2 = CalculateTwoStopsDistance2(p2, p3);
//
//    auto d_total = (d1 + d2) * 2;
//
//    cout << "d1: " << d1 << endl;
//    cout << "d2: " << d2 << endl;
//    cout << "d_total: " << d_total << endl;

    auto manager = bus_manager::BusManager();

    size_t query_num;
//    test_stream >> query_num;
    cin >> query_num;
//    cout << "query_num " << query_num << endl;
    manager.ReadBaseQueries(cin, query_num);
//    manager.ReadBaseQueries(test_stream, query_num);

    manager.ConnectStations();

//    test_stream >> query_num;
    cin >> query_num;
//    manager.ProcessSearchQueries(test_stream, query_num);
    manager.ProcessSearchQueries(cin, query_num);
    return 0;
}
