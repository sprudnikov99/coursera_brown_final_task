#include<iostream>
#include<unordered_map>
#include<array>
#include<optional>

#include "common.h"

namespace cache
{
    static constexpr size_t kMaxStopsNum = 100;
    static constexpr double kRouteInitValue = -1.0;

    class Cache
    {
    public:
        Cache();

        [[nodiscard]] std::optional<std::size_t> GetUniqueStops(BusId bus_id) const;
        void UpdateUniqueStops(BusId bus_id, size_t value);

        [[nodiscard]] std::optional<double> GetBusRouteLength(BusId bus_id) const;
        void UpdateBusRouteLength(BusId bus_id, double value);

        [[nodiscard]] std::optional<double> GetTwoStopsDistance(size_t stop_from, size_t stop_to) const;
        void UpdateTwoStopsDistance(size_t stop_from, size_t stop_to, double value);

    private:
        std::array<std::array<double, kMaxStopsNum>, kMaxStopsNum> m_routes_cache = {};
        std::unordered_map<BusId, std::size_t> m_unique_cache = {};
        std::unordered_map<BusId, double> m_bus_length_cache = {};
    };
}

